# payroll/admin.py (CLEAN + FIXED - FULL FILE)
# ✅ Removes duplicates
# ✅ Fixes Employee search_fields (uses full_name)
# ✅ Uses *filtered* queryset (respects search + filters + date hierarchy)
# ✅ Fixes quick_filters (no NoneType / preserves params safely)
# ✅ Provides month options + recent rows as dicts for template

from __future__ import annotations
import csv
from datetime import date, timedelta
from decimal import Decimal
from django.http import HttpResponse, JsonResponse
from django.contrib import admin, messages
from django.db.models import Count, Sum
from django.db.models.functions import TruncMonth
from django.shortcuts import render
from django.urls import path, reverse
from django.utils.html import format_html
from django.utils.http import urlencode
from django.utils.timezone import localdate, now
from unfold.admin import ModelAdmin

from accounts.models import Employee, Team
from .models import (
    Expense,
    GlobalSetting,
    EmployeeSalary,
    SalaryPayment,
    PMSalaryShare,
    PMResponsibility,  # kept import in case used elsewhere
)


# -----------------------------
# Helpers
# -----------------------------
def fmt_money(v, currency: str = "USD") -> str:
    if v is None:
        return "—"
    return f"{v:,.2f} {currency}"


def per_employee_totals(employee_ids=None):
    """
    Returns dict keyed by employee_id with:
    salary_usd, salary_pkr,
    paid_usd, paid_pkr, paid_pm_usd, paid_admin_usd,
    exp_usd, exp_pkr
    """
    data = {}
    qs_e = Employee.objects.all()
    if employee_ids is not None:
        qs_e = qs_e.filter(id__in=employee_ids)

    sal = (
        EmployeeSalary.objects.filter(employee__in=qs_e)
        .values("employee_id")
        .annotate(
            salary_usd=Sum("monthly_salary_usd"),
            salary_pkr=Sum("monthly_salary_pkr"),
        )
    )
    for r in sal:
        data.setdefault(r["employee_id"], {}).update(
            {
                "salary_usd": r["salary_usd"] or Decimal("0"),
                "salary_pkr": r["salary_pkr"] or Decimal("0"),
            }
        )

    paid = (
        SalaryPayment.objects.filter(employee__in=qs_e)
        .values("employee_id")
        .annotate(
            paid_usd=Sum("amount_usd"),
            paid_pkr=Sum("amount_pkr"),
            paid_pm_usd=Sum("pm_share_usd"),
            paid_admin_usd=Sum("admin_share_usd"),
        )
    )
    for r in paid:
        data.setdefault(r["employee_id"], {}).update(
            {
                "paid_usd": r["paid_usd"] or Decimal("0"),
                "paid_pkr": r["paid_pkr"] or Decimal("0"),
                "paid_pm_usd": r["paid_pm_usd"] or Decimal("0"),
                "paid_admin_usd": r["paid_admin_usd"] or Decimal("0"),
            }
        )

    ex = (
        Expense.objects.filter(employee__in=qs_e)
        .values("employee_id")
        .annotate(
            exp_usd=Sum("amount_usd"),
            exp_pkr=Sum("amount_pkr"),
        )
    )
    for r in ex:
        data.setdefault(r["employee_id"], {}).update(
            {
                "exp_usd": r["exp_usd"] or Decimal("0"),
                "exp_pkr": r["exp_pkr"] or Decimal("0"),
            }
        )

    # fill missing keys
    for e_id in qs_e.values_list("id", flat=True):
        data.setdefault(e_id, {}).setdefault("salary_usd", Decimal("0"))
        data[e_id].setdefault("salary_pkr", Decimal("0"))
        data[e_id].setdefault("paid_usd", Decimal("0"))
        data[e_id].setdefault("paid_pkr", Decimal("0"))
        data[e_id].setdefault("paid_pm_usd", Decimal("0"))
        data[e_id].setdefault("paid_admin_usd", Decimal("0"))
        data[e_id].setdefault("exp_usd", Decimal("0"))
        data[e_id].setdefault("exp_pkr", Decimal("0"))

    return data


def _safe_querystring(base_get, **updates) -> str:
    """
    Build querystring from request.GET while updating/removing keys safely.

    Example:
      _safe_querystring(request.GET, date__gte="2025-12-01", date__lt="2026-01-01")
      _safe_querystring(request.GET, date__gte=None, date__lt=None)  # removes keys
    """
    q = base_get.copy()
    for k, v in updates.items():
        if v is None:
            q.pop(k, None)
        else:
            q[k] = v
    return "?" + urlencode(q, doseq=True) if q else "?"


def _next_month_start(d: date) -> date:
    if d.month == 12:
        return d.replace(year=d.year + 1, month=1, day=1)
    return d.replace(month=d.month + 1, day=1)


# -----------------------------
# PMSalaryShare
# -----------------------------
@admin.register(PMSalaryShare)
class PMSalaryShareAdmin(ModelAdmin):
    list_display = ("pm", "share_percentage", "note")
    search_fields = ("pm__full_name", "pm__email")
    list_editable = ("share_percentage",)


# -----------------------------
# GlobalSetting (Dashboard + Summary)
# -----------------------------
@admin.register(GlobalSetting)
class GlobalSettingAdmin(ModelAdmin):
    list_display = ("usd_to_pkr_rate", "updated_at", "note")
    search_fields = ("note",)
    actions = ["recalculate_all_pkr"]

    change_list_template = "admin/payroll/globalsetting_changelist.html"
    change_form_template = "admin/payroll/globalsetting/change_form.html"

    def has_add_permission(self, request):
        return request.user.is_superuser

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                "dashboard/",
                self.admin_site.admin_view(self.dashboard_view),
                name="payroll_dashboard",
            ),
            path(
                "summary/",
                self.admin_site.admin_view(self.summary_view),
                name="payroll_company_summary",
            ),
        ]
        return custom + urls

    def dashboard_view(self, request):
        salaries = EmployeeSalary.objects.aggregate(
            total_usd=Sum("monthly_salary_usd"),
            total_pkr=Sum("monthly_salary_pkr"),
        )
        paid = SalaryPayment.objects.aggregate(
            total_usd=Sum("amount_usd"),
            total_pkr=Sum("amount_pkr"),
        )
        expenses = Expense.objects.aggregate(
            total_usd=Sum("amount_usd"),
            total_pkr=Sum("amount_pkr"),
        )

        teams = []
        for team in Team.objects.all():
            emp_ids = team.members.values_list("id", flat=True)

            total_salary = (
                EmployeeSalary.objects.filter(employee__in=emp_ids).aggregate(
                    total=Sum("monthly_salary_usd")
                )["total"]
                or Decimal("0")
            )

            paid_usd = (
                SalaryPayment.objects.filter(employee__in=emp_ids).aggregate(
                    total=Sum("amount_usd")
                )["total"]
                or Decimal("0")
            )

            try:
                share_obj = PMSalaryShare.objects.get(pm=team.project_manager)
                pm_share = total_salary * (share_obj.share_percentage / Decimal("100"))
            except PMSalaryShare.DoesNotExist:
                pm_share = total_salary / 2

            admin_share = total_salary - pm_share

            teams.append(
                {
                    "pm": team.project_manager,
                    "total_salary_usd": total_salary,
                    "paid_usd": paid_usd,
                    "pm_share": pm_share,
                    "admin_share": admin_share,
                    "remaining_pm_usd": pm_share - paid_usd,
                }
            )

        remaining_pkr = (salaries["total_pkr"] or Decimal("0")) - (
            paid["total_pkr"] or Decimal("0")
        ) - (expenses["total_pkr"] or Decimal("0"))

        context = dict(
            self.admin_site.each_context(request),
            title="Payroll Dashboard",
            salaries=salaries,
            paid=paid,
            expenses=expenses,
            teams=teams,
            remaining_pkr=remaining_pkr,
            rate=GlobalSetting.current_rate(),
        )
        return render(request, "admin/payroll_dashboard.html", context)

    def summary_view(self, request):
        salaries = EmployeeSalary.objects.aggregate(
            total_usd=Sum("monthly_salary_usd"),
            total_pkr=Sum("monthly_salary_pkr"),
        )
        paid = SalaryPayment.objects.aggregate(
            total_usd=Sum("amount_usd"),
            total_pkr=Sum("amount_pkr"),
            total_pm_usd=Sum("pm_share_usd"),
            total_admin_usd=Sum("admin_share_usd"),
        )
        expenses = Expense.objects.aggregate(
            total_usd=Sum("amount_usd"),
            total_pkr=Sum("amount_pkr"),
        )

        cat_breakdown = (
            Expense.objects.values("category")
            .annotate(usd=Sum("amount_usd"), pkr=Sum("amount_pkr"))
            .order_by("category")
        )

        remaining_pkr = (salaries["total_pkr"] or Decimal("0")) - (
            paid["total_pkr"] or Decimal("0")
        ) - (expenses["total_pkr"] or Decimal("0"))

        context = dict(
            self.admin_site.each_context(request),
            title="Payroll Summary",
            now=now(),
            rate=GlobalSetting.current_rate(),
            salaries=salaries,
            paid=paid,
            expenses=expenses,
            cat_breakdown=cat_breakdown,
            remaining_pkr=remaining_pkr,
        )
        return render(request, "admin/payroll_company_summary.html", context)

    @admin.action(
        description="Recalculate PKR for all salaries/payments/expenses using the latest USD rate"
    )
    def recalculate_all_pkr(self, request, queryset):
        rate = GlobalSetting.current_rate()

        for obj in EmployeeSalary.objects.all():
            obj.save(request=request)
        for obj in SalaryPayment.objects.all():
            obj.save(request=request)
        for obj in Expense.objects.all():
            obj.save(request=request)

        self.message_user(
            request,
            f"Recalculated PKR amounts with USD→PKR rate {rate}.",
            level=messages.SUCCESS,
        )


# -----------------------------
# EmployeeSalary
# -----------------------------
@admin.register(EmployeeSalary)
class EmployeeSalaryAdmin(ModelAdmin):
    list_display = (
        "employee",
        "monthly_salary_usd_fmt",
        "monthly_salary_pkr_fmt",
        "effective_from",
        "active",
        "paid_so_far_usd_fmt",
        "paid_so_far_pkr_fmt",
        "paid_pm_usd_fmt",
        "paid_admin_usd_fmt",
        "expenses_usd_fmt",
        "expenses_pkr_fmt",
        "remaining_pkr_fmt",
    )
    list_filter = ("active", "effective_from")
    search_fields = ("employee__full_name",  "employee__email")
    autocomplete_fields = ("employee",)

    change_list_template = "admin/payroll/salary_changelist.html"
    change_form_template = "admin/payroll/salary_change_form.html"

    def change_view(self, request, object_id, form_url="", extra_context=None):
        obj = self.get_object(request, object_id)
        extra_context = extra_context or {}

        if obj:
            history = (
                EmployeeSalary.objects.filter(employee=obj.employee)
                .order_by("-salary_month", "-id")
            )

            totals = history.aggregate(
                total_usd=Sum("monthly_salary_usd"),
                total_pkr=Sum("monthly_salary_pkr"),
            )

            salary_history_url = (
                reverse("admin:payroll_employeesalary_changelist")
                + "?"
                + urlencode({"employee__id__exact": obj.employee_id})
            )
            payments_url = (
                reverse("admin:payroll_salarypayment_changelist")
                + "?"
                + urlencode({"employee__id__exact": obj.employee_id})
            )
            expenses_url = (
                reverse("admin:payroll_expense_changelist")
                + "?"
                + urlencode({"employee__id__exact": obj.employee_id})
            )
            add_new_month_url = (
                reverse("admin:payroll_employeesalary_add")
                + "?"
                + urlencode({"employee": obj.employee_id})
            )

            extra_context.update(
                {
                    "salary_obj": obj,
                    "employee_obj": obj.employee,
                    "salary_history": history,
                    "history_totals": totals,
                    "salary_history_url": salary_history_url,
                    "payments_url": payments_url,
                    "expenses_url": expenses_url,
                    "add_new_month_url": add_new_month_url,
                    "rate": GlobalSetting.current_rate(),
                    "today": localdate(),
                }
            )

        return super().change_view(
            request, object_id, form_url, extra_context=extra_context
        )

    def get_queryset(self, request):
        qs = super().get_queryset(request).select_related("employee")
        if request.user.is_superuser:
            return qs
        if getattr(request.user, "role", None) == "pm":
            try:
                team = Team.objects.get(project_manager=request.user)
                return qs.filter(employee__in=team.members.all())
            except Team.DoesNotExist:
                return qs.none()
        return qs.none()

    def changelist_view(self, request, extra_context=None):
        qs = self.get_queryset(request)
        totals = qs.aggregate(
            total_usd=Sum("monthly_salary_usd"),
            total_pkr=Sum("monthly_salary_pkr"),
        )

        cards = []
        for obj in qs:
            t = per_employee_totals([obj.employee_id]).get(obj.employee_id, {})
            remaining = (t.get("salary_pkr") or Decimal("0")) - (
                t.get("paid_pkr") or Decimal("0")
            ) - (t.get("exp_pkr") or Decimal("0"))

            cards.append(
                {
                    "id": obj.id,
                    "employee": obj.employee,
                    "active": bool(obj.active),
                    "effective_from": obj.effective_from,
                    "monthly_usd": obj.monthly_salary_usd or Decimal("0"),
                    "monthly_pkr": obj.monthly_salary_pkr or Decimal("0"),
                    "paid_usd": t.get("paid_usd") or Decimal("0"),
                    "paid_pkr": t.get("paid_pkr") or Decimal("0"),
                    "exp_usd": t.get("exp_usd") or Decimal("0"),
                    "exp_pkr": t.get("exp_pkr") or Decimal("0"),
                    "remaining_pkr": remaining,
                }
            )

        extra_context = extra_context or {}
        extra_context["summary"] = {
            "title": "Total Monthly Salaries",
            "usd": totals["total_usd"] or Decimal("0"),
            "pkr": totals["total_pkr"] or Decimal("0"),
        }
        extra_context["cards"] = cards
        return super().changelist_view(request, extra_context=extra_context)

    def save_model(self, request, obj, form, change):
        obj.save(request=request)

    def has_module_permission(self, request):
        return request.user.is_superuser or getattr(request.user, "role", None) == "pm"

    # formatters
    def monthly_salary_usd_fmt(self, obj):
        return fmt_money(obj.monthly_salary_usd, "USD")

    def monthly_salary_pkr_fmt(self, obj):
        return fmt_money(obj.monthly_salary_pkr, "PKR")

    def _get_totals(self, obj):
        return per_employee_totals([obj.employee_id]).get(obj.employee_id, {})

    def paid_so_far_usd_fmt(self, obj):
        return fmt_money(self._get_totals(obj).get("paid_usd"), "USD")

    def paid_so_far_pkr_fmt(self, obj):
        return fmt_money(self._get_totals(obj).get("paid_pkr"), "PKR")

    def paid_pm_usd_fmt(self, obj):
        return fmt_money(self._get_totals(obj).get("paid_pm_usd"), "USD")

    def paid_admin_usd_fmt(self, obj):
        return fmt_money(self._get_totals(obj).get("paid_admin_usd"), "USD")

    def expenses_usd_fmt(self, obj):
        return fmt_money(self._get_totals(obj).get("exp_usd"), "USD")

    def expenses_pkr_fmt(self, obj):
        return fmt_money(self._get_totals(obj).get("exp_pkr"), "PKR")

    def remaining_pkr_fmt(self, obj):
        t = self._get_totals(obj)
        remaining = (t.get("salary_pkr") or Decimal("0")) - (
            t.get("paid_pkr") or Decimal("0")
        ) - (t.get("exp_pkr") or Decimal("0"))
        return format_html("<b>{}</b>", fmt_money(remaining, "PKR"))

    monthly_salary_usd_fmt.short_description = "Monthly Salary (USD)"
    monthly_salary_pkr_fmt.short_description = "Monthly Salary (PKR)"
    paid_so_far_usd_fmt.short_description = "Paid Salary (USD)"
    paid_so_far_pkr_fmt.short_description = "Paid Salary (PKR)"
    paid_pm_usd_fmt.short_description = "PM Share (USD)"
    paid_admin_usd_fmt.short_description = "Admin Share (USD)"
    expenses_usd_fmt.short_description = "Expenses (USD)"
    expenses_pkr_fmt.short_description = "Expenses (PKR)"
    remaining_pkr_fmt.short_description = "Remaining (PKR)"

    class Media:
        css = {
            "all": (
                "css/admin/payroll_salary_cards.css",
                "css/admin/payroll_salary_detail.css",
            )
        }


# -----------------------------
# SalaryPayment
# -----------------------------
@admin.register(SalaryPayment)
class SalaryPaymentAdmin(ModelAdmin):
    list_display = (
        "employee",
        "amount_usd_fmt",
        "amount_pkr_fmt",
        "pm_share_fmt",
        "admin_share_fmt",
        "date_paid",
        "reference",
        "created_at",
    )

    # ✅ Inline editing for common field
    list_editable = ("reference",)

    list_filter = ("date_paid",)
    search_fields = (
        "employee__full_name",
        "employee__email",
        "reference",
        "note",
    )
    autocomplete_fields = ("employee",)
    date_hierarchy = "date_paid"

    change_list_template = "admin/payroll/payment_changelist.html"
    change_form_template = "admin/payroll/payment_change_form.html"


    actions = [
        "recalculate_pkr",
        "export_selected_csv",
        "autofill_missing_reference",
    ]

    # performance
    list_select_related = ("employee",)

    def get_queryset(self, request):
        qs = super().get_queryset(request).select_related("employee")
        if request.user.is_superuser:
            return qs
        if getattr(request.user, "role", None) == "pm":
            try:
                team = Team.objects.get(project_manager=request.user)
                return qs.filter(employee__in=team.members.all())
            except Team.DoesNotExist:
                return qs.none()
        return qs.none()

    # ---------------------------
    # Custom URLs (Export + Preview)
    # ---------------------------
    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                "export/csv/",
                self.admin_site.admin_view(self.export_current_csv),
                name="payroll_salarypayment_export_csv",
            ),
            path(
                "preview/<int:pk>/",
                self.admin_site.admin_view(self.preview_payment),
                name="payroll_salarypayment_preview",
            ),
        ]
        return custom + urls

    # ---------------------------
    # Export (current filtered view)
    # ---------------------------
    def export_current_csv(self, request):
        """
        Exports the *current changelist queryset* (respects search, filters, date_hierarchy, etc).
        """
        cl = self.get_changelist_instance(request)
        qs = cl.get_queryset(request)

        resp = HttpResponse(content_type="text/csv")
        resp["Content-Disposition"] = 'attachment; filename="salary_payments.csv"'
        w = csv.writer(resp)

        w.writerow(
            [
                "Employee",
                "Employee Email",
                "Amount USD",
                "Amount PKR",
                "PM Share USD",
                "Admin Share USD",
                "Date Paid",
                "Reference",
                "Created At",
            ]
        )
        for obj in qs:
            w.writerow(
                [
                    getattr(obj.employee, "full_name", str(obj.employee)),
                    getattr(obj.employee, "email", ""),
                    obj.amount_usd or 0,
                    obj.amount_pkr or 0,
                    obj.pm_share_usd or 0,
                    obj.admin_share_usd or 0,
                    obj.date_paid,
                    obj.reference or "",
                    obj.created_at,
                ]
            )
        return resp

    # ---------------------------
    # Quick preview JSON
    # ---------------------------
    def preview_payment(self, request, pk):
        obj = self.get_queryset(request).filter(pk=pk).first()
        if not obj:
            return JsonResponse({"ok": False}, status=404)

        data = {
            "ok": True,
            "employee": getattr(obj.employee, "full_name", str(obj.employee)),
            "email": getattr(obj.employee, "email", ""),
            "amount_usd": fmt_money(obj.amount_usd, "USD"),
            "amount_pkr": fmt_money(obj.amount_pkr, "PKR"),
            "pm_share": fmt_money(obj.pm_share_usd, "USD"),
            "admin_share": fmt_money(obj.admin_share_usd, "USD"),
            "date_paid": str(obj.date_paid),
            "reference": obj.reference or "—",
            "note": getattr(obj, "note", "") or "—",
            "created_at": str(obj.created_at),
        }
        return JsonResponse(data)

    # ---------------------------
    # Dashboard context + modern quick filters
    # ---------------------------
    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}

        qs = self.get_queryset(request)

        totals = qs.aggregate(
            total_usd=Sum("amount_usd"),
            total_pkr=Sum("amount_pkr"),
            total_pm_usd=Sum("pm_share_usd"),
            total_admin_usd=Sum("admin_share_usd"),
        )

        # Anomalies
        missing_ref = qs.filter(reference__isnull=True).count() + qs.filter(reference="").count()
        high_threshold = Decimal("500")
        high_count = qs.filter(amount_usd__gte=high_threshold).count()

        # helper: keep existing GET params + apply updates
        def _qs(base_get, **updates):
            q = base_get.copy()
            for k, v in updates.items():
                if v is None:
                    q.pop(k, None)
                else:
                    q[k] = v
            return "?" + urlencode(q, doseq=True) if q else "?"

        base_get = request.GET

        today = localdate()
        tomorrow = today + timedelta(days=1)

        this_month_start = today.replace(day=1)
        if this_month_start.month == 12:
            next_month_start = this_month_start.replace(year=this_month_start.year + 1, month=1)
        else:
            next_month_start = this_month_start.replace(month=this_month_start.month + 1)

        last_30_start = today - timedelta(days=30)

        quick_filters = {
            "today": _qs(base_get, date_paid__gte=str(today), date_paid__lt=str(tomorrow)),
            "this_month": _qs(base_get, date_paid__gte=str(this_month_start), date_paid__lt=str(next_month_start)),
            "last_30": _qs(base_get, date_paid__gte=str(last_30_start), date_paid__lt=str(tomorrow)),
            "clear": "?",
        }


        # Export URL (keeps query string)
        export_url = "export/csv/" + (("?" + base_get.urlencode()) if base_get.urlencode() else "")

        extra_context["summary"] = {
            "title": "Salary Payments",
            "usd": totals["total_usd"] or Decimal("0"),
            "pkr": totals["total_pkr"] or Decimal("0"),
            "pm_usd": totals["total_pm_usd"] or Decimal("0"),
            "admin_usd": totals["total_admin_usd"] or Decimal("0"),
            "rate": GlobalSetting.current_rate() if hasattr(GlobalSetting, "current_rate") else None,
            "quick_filters": quick_filters,
            "export_url": export_url,
            "alerts": {
                "missing_ref": missing_ref,
                "high_count": high_count,
                "high_threshold": str(high_threshold),
            },
        }

        return super().changelist_view(request, extra_context=extra_context)

    # ---------------------------
    # Actions
    # ---------------------------
    @admin.action(description="Recalculate PKR for selected payments")
    def recalculate_pkr(self, request, queryset):
        for obj in queryset:
            obj.save(request=request)
        self.message_user(request, "PKR recalculated for selected payments.", level=messages.SUCCESS)

    @admin.action(description="Export selected as CSV")
    def export_selected_csv(self, request, queryset):
        resp = HttpResponse(content_type="text/csv")
        resp["Content-Disposition"] = 'attachment; filename="salary_payments_selected.csv"'
        w = csv.writer(resp)
        w.writerow(["Employee", "Amount USD", "Amount PKR", "Date Paid", "Reference", "Created At"])
        for obj in queryset.select_related("employee"):
            w.writerow(
                [
                    getattr(obj.employee, "full_name", str(obj.employee)),
                    obj.amount_usd or 0,
                    obj.amount_pkr or 0,
                    obj.date_paid,
                    obj.reference or "",
                    obj.created_at,
                ]
            )
        return resp

    @admin.action(description="Auto-fill empty reference with employee name (selected)")
    def autofill_missing_reference(self, request, queryset):
        updated = 0
        for obj in queryset.select_related("employee"):
            if not obj.reference:
                obj.reference = getattr(obj.employee, "full_name", "Payment")
                obj.save(update_fields=["reference"])
                updated += 1
        self.message_user(request, f"Updated {updated} payments with missing reference.", level=messages.SUCCESS)

    # ---------------------------
    # Formatters
    # ---------------------------
    def amount_usd_fmt(self, obj):
        return fmt_money(obj.amount_usd, "USD")

    def amount_pkr_fmt(self, obj):
        return fmt_money(obj.amount_pkr, "PKR")

    def pm_share_fmt(self, obj):
        return fmt_money(obj.pm_share_usd, "USD")

    def admin_share_fmt(self, obj):
        return fmt_money(obj.admin_share_usd, "USD")

    amount_usd_fmt.short_description = "Amount (USD)"
    amount_pkr_fmt.short_description = "Amount (PKR)"
    pm_share_fmt.short_description = "PM Share (USD)"
    admin_share_fmt.short_description = "Admin Share (USD)"
# -----------------------------
# Expense
# -----------------------------
@admin.register(Expense)
class ExpenseAdmin(ModelAdmin):
    list_display = (
        "employee",
        "category",
        "amount_usd_fmt",
        "amount_pkr_fmt",
        "date",
        "short_notes",
        "created_at",
    )
    list_filter = ("category", "date")
    search_fields = (
        "employee__full_name",
        "employee__email",
        "category",
        "notes",
    )
    autocomplete_fields = ("employee",)
    date_hierarchy = "date"

    change_list_template = "admin/payroll/expense_changelist.html"
    change_form_template = "admin/payroll/expense/change_form.html"

    def get_queryset(self, request):
        qs = super().get_queryset(request).select_related("employee")
        if request.user.is_superuser:
            return qs
        if getattr(request.user, "role", None) == "pm":
            try:
                team = Team.objects.get(project_manager=request.user)
                return qs.filter(employee__in=team.members.all())
            except Team.DoesNotExist:
                return qs.none()
        return qs.none()

    def _filtered_queryset(self, request):
        """
        ✅ IMPORTANT:
        The admin changelist applies search/filter/date hierarchy at the ChangeList level.
        If we want dashboard numbers to match what's on screen, we must use that queryset.
        """
        cl = self.get_changelist_instance(request)
        return cl.get_queryset(request)

    def changelist_view(self, request, extra_context=None):
        # ✅ Use filtered queryset (respects q=, category filter, date_hierarchy, etc.)
        qs = self._filtered_queryset(request)

        # Totals
        totals = qs.aggregate(
            total_usd=Sum("amount_usd"),
            total_pkr=Sum("amount_pkr"),
        )
        total_usd = totals["total_usd"] or Decimal("0")
        total_pkr = totals["total_pkr"] or Decimal("0")
        count = qs.count()

        # Breakdown by category (USD/PKR + count)
        breakdown = (
            qs.values("category")
            .annotate(
                usd=Sum("amount_usd"),
                pkr=Sum("amount_pkr"),
                cnt=Count("id"),
            )
            .order_by("-usd")
        )

        top = breakdown.first()
        top_category = top["category"] if top else "—"
        top_usd = (top.get("usd") or Decimal("0")) if top else Decimal("0")
        top_pkr = (top.get("pkr") or Decimal("0")) if top else Decimal("0")

        breakdown_rows = []
        for row in breakdown:
            usd_val = row["usd"] or Decimal("0")
            pkr_val = row["pkr"] or Decimal("0")
            pct = (usd_val / total_usd * 100) if total_usd > 0 else Decimal("0")
            breakdown_rows.append(
                {
                    "category": row["category"],
                    "usd": usd_val,
                    "pkr": pkr_val,
                    "pct": pct,
                    "cnt": row["cnt"] or 0,
                }
            )

        # Monthly trend (based on current filters)
        monthly = (
            qs.annotate(m=TruncMonth("date"))
            .values("m")
            .annotate(
                usd=Sum("amount_usd"),
                pkr=Sum("amount_pkr"),
                cnt=Count("id"),
            )
            .order_by("m")
        )

        trend_labels, trend_usd, trend_pkr, trend_cnt = [], [], [], []
        for r in monthly:
            m = r["m"]
            trend_labels.append(m.strftime("%b %Y") if m else "—")
            trend_usd.append(float(r["usd"] or 0))
            trend_pkr.append(float(r["pkr"] or 0))
            trend_cnt.append(int(r["cnt"] or 0))

        # Top spenders
        top_employees = (
            qs.values("employee__full_name", "employee__email")
            .annotate(
                usd=Sum("amount_usd"),
                pkr=Sum("amount_pkr"),
                cnt=Count("id"),
            )
            .order_by("-usd")[:7]
        )

        # Recent (as dicts so template is predictable)
        recent_qs = qs.order_by("-date", "-created_at")[:7]
        recent = []
        for r in recent_qs:
            recent.append(
                {
                    "employee": getattr(r.employee, "full_name", str(r.employee)),
                    "category": r.category,
                    "date": r.date,
                    "amount_usd": r.amount_usd,
                    "amount_pkr": r.amount_pkr,
                    "notes": r.notes,
                }
            )

        # Quick filters (date ranges)
        today = localdate()
        tomorrow = today + timedelta(days=1)
        this_month_start = today.replace(day=1)
        next_month_start = _next_month_start(this_month_start)
        last_30_start = today - timedelta(days=30)

        # ✅ Preserve existing query params (like q, category, etc.) while changing date range
        base_get = request.GET

        quick_filters = {
            "today": _safe_querystring(base_get, date__gte=str(today), date__lt=str(tomorrow)),
            "this_month": _safe_querystring(
                base_get, date__gte=str(this_month_start), date__lt=str(next_month_start)
            ),
            "last_30": _safe_querystring(base_get, date__gte=str(last_30_start), date__lt=str(tomorrow)),
            "clear": "?",  # full clear
        }

        # Month options (last 12 months) for "Pick month" UI in template
        month_options = []
        cursor = this_month_start
        for _ in range(12):
            m_start = cursor
            m_next = _next_month_start(m_start)
            month_options.append(
                {
                    "label": m_start.strftime("%b %Y"),
                    "year": m_start.year,
                    "month": m_start.month,
                    "url": _safe_querystring(base_get, date__gte=str(m_start), date__lt=str(m_next)),
                }
            )
            # go back one month
            if cursor.month == 1:
                cursor = cursor.replace(year=cursor.year - 1, month=12, day=1)
            else:
                cursor = cursor.replace(month=cursor.month - 1, day=1)

        extra_context = extra_context or {}
        extra_context["summary"] = {
            "title": "Total Expenses",
            "usd": total_usd,
            "pkr": total_pkr,
            "count": count,
            "top_category": top_category,
            "top_usd": top_usd,
            "top_pkr": top_pkr,
            "breakdown": breakdown_rows,
            # charts
            "trend_labels": trend_labels,
            "trend_usd": trend_usd,
            "trend_pkr": trend_pkr,
            "trend_cnt": trend_cnt,
            # widgets
            "top_employees": list(top_employees),
            "recent": recent,
            # quick links
            "quick_filters": quick_filters,
            "month_options": month_options,
            # helper for pick date default
            "today_iso": str(today),
        }

        return super().changelist_view(request, extra_context=extra_context)

    def save_model(self, request, obj, form, change):
        obj.save(request=request)

    def has_module_permission(self, request):
        return request.user.is_superuser or getattr(request.user, "role", None) == "pm"

    def amount_usd_fmt(self, obj):
        return fmt_money(obj.amount_usd, "USD")

    def amount_pkr_fmt(self, obj):
        return fmt_money(obj.amount_pkr, "PKR")

    def short_notes(self, obj):
        return (
            (obj.notes[:60] + "…")
            if obj.notes and len(obj.notes) > 60
            else (obj.notes or "—")
        )

    amount_usd_fmt.short_description = "Amount (USD)"
    amount_pkr_fmt.short_description = "Amount (PKR)"
    short_notes.short_description = "Notes"
