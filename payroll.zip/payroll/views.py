from decimal import Decimal
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from payroll.models import EmployeeSalary, SalaryPayment, Expense
from accounts.models import Employee

@login_required
def user_payroll_summary(request):
    employee = request.user


    # Salary profile
    salary_profile = EmployeeSalary.objects.filter(employee=employee, active=True).first()

    # Payments & Expenses
    payments = SalaryPayment.objects.filter(employee=employee).order_by("-date_paid")
    expenses = Expense.objects.filter(employee=employee).order_by("-date")

    # Totals
    total_salary_usd = salary_profile.monthly_salary_usd if salary_profile else Decimal("0")
    total_salary_pkr = salary_profile.monthly_salary_pkr if salary_profile else Decimal("0")

    total_paid_usd = sum(p.amount_usd for p in payments)
    total_paid_pkr = sum(p.amount_pkr for p in payments)

    total_expenses_usd = sum(e.amount_usd for e in expenses)
    total_expenses_pkr = sum(e.amount_pkr for e in expenses)

    remaining_pkr = total_salary_pkr - total_paid_pkr - total_expenses_pkr

    context = {
        "employee": employee,
        "salary_profile": salary_profile,
        "payments": payments,
        "expenses": expenses,
        "total_salary_usd": total_salary_usd,
        "total_salary_pkr": total_salary_pkr,
        "total_paid_usd": total_paid_usd,
        "total_paid_pkr": total_paid_pkr,
        "total_expenses_usd": total_expenses_usd,
        "total_expenses_pkr": total_expenses_pkr,
        "remaining_pkr": remaining_pkr,
    }
    return render(request, "payroll/my_summary.html", context)
